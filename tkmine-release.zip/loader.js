"use strict";
import(chrome.runtime.getURL("content.js"));
