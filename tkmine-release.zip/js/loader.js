"use strict";
import(chrome.runtime.getURL("js/content.js"));
